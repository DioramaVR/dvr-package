Licences for Fake Game VR (test data)
